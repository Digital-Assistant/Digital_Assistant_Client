<<<<<<< HEAD
var UdanLibrary;
/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************!*\
  !*** ./src/InjectHeaders.js ***!
  \******************************/
var _chrome;
var s = document.createElement('script');
var scriptpath = (_chrome = chrome) === null || _chrome === void 0 || (_chrome = _chrome.runtime) === null || _chrome === void 0 ? void 0 : _chrome.getURL("assets/UDAHeaders.js");
s.src = scriptpath;
s.onload = function () {};
(document.head || document.documentElement).appendChild(s);
UdanLibrary = __webpack_exports__;
/******/ })()
;
//# sourceMappingURL=UDAInjectHeaders.js.map
=======
var UdanLibrary;(()=>{var e;let n=document.createElement("script"),d=null===(e=chrome)||void 0===e||null===(e=e.runtime)||void 0===e?void 0:e.getURL("assets/UDAHeaders.js");n.src=d,n.onload=function(){},(document.head||document.documentElement).appendChild(n),UdanLibrary={}})();
>>>>>>> 26f4371d2009adedbcbf213c05d9245d994885b4
